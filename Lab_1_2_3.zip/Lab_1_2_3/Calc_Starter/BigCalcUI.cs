﻿using Calculator;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class BigCalcUI : Form
    {
        private const string oneOut = "1";
        private const string twoOut = "2";
        private const string threeOut = "3";
        private const string fourOut = "4";
        private const string fiveOut = "5";
        private const string sixOut = "6";
        private const string sevenOut = "7";
        private const string eightOut = "8";
        private const string nineOut = "9";
        private const string zeroOut = "0";
        public BigCalcUI()
        {
            InitializeComponent();
            VersionInfo.Text = CalcEngine.GetVersion();
            OutputDisplay.Text = "0";
        }
        static void Main()
        {
            Application.Run(new CalcUI());
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, helpProvider2.HelpNamespace);
        }

        private void smallVersionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalcUI smallCalc = new CalcUI();
            smallCalc.Show(this);
            this.Close();
        }

        private void KeyExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void KeyClear_Click(object sender, EventArgs e)
        {
            CalcEngine.CalcReset();
            OutputDisplay.Text = "0";
        }

        private void KeyEqual_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcEqual();
            CalcEngine.CalcReset();
        }

        private void KeyDate_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.GetDate();
            CalcEngine.CalcReset();
        }

        private void KeyPlus_Click(object sender, EventArgs e)
        {
            CalcEngine.CalcOperation(CalcEngine.Operator.eAdd);
        }

        private void KeyMinus_Click(object sender, EventArgs e)
        {
            CalcEngine.CalcOperation(CalcEngine.Operator.eSubtract);
        }

        private void KeyMultiply_Click(object sender, EventArgs e)
        {
            CalcEngine.CalcOperation(CalcEngine.Operator.eMultiply);
        }

        private void KeyDivide_Click(object sender, EventArgs e)
        {
            CalcEngine.CalcOperation(CalcEngine.Operator.eDivide);
        }

        private void KeyZero_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcNumber(zeroOut);
        }

        private void KeyOne_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcNumber(oneOut);
        }

        private void KeyTwo_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcNumber(twoOut);
        }

        private void KeyThree_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcNumber(threeOut);
        }

        private void KeyFour_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcNumber(fourOut);
        }

        private void KeyFive_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcNumber(fiveOut);
        }

        private void KeySix_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcNumber(sixOut);
        }

        private void KeySeven_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcNumber(sevenOut);
        }

        private void KeyEight_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcNumber(eightOut);
        }

        private void KeyNine_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcNumber(nineOut);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CalcEngine.CalcOperation(CalcEngine.Operator.eStepen);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcSqrt();
        }

        private void KeySign_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcSign();
        }

        private void KeyPoint_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcDecimal();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcObratnoe();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OutputDisplay.Text = CalcEngine.CalcKvadrat();
        }

        private async void button5_Click(object sender, EventArgs e)
        {
            FactBox.Text = "wait please";
            FactBox.Text = await CalcEngine.CalcKFactorial();
            OutputDisplay.Text = "0";
        }

        private void quadraticToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Quadratic quad = new Quadratic();
            quad.Show(this);
        }

        private void exitToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }
    }
}
